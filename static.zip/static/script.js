function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');
}

async function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const status = document.getElementById('loginStatus');

    const response = await fetch('/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });

    const result = await response.json();
    status.textContent = result.message;

    if (result.success) {
        window.location.href = '/admin';
    }
}

async function processTransaction() {
    const drug = document.getElementById('drugSelect').value;
    const status = document.getElementById('transactionStatus');
    const timestamp = new Date().toISOString();

    const transaction = {
        product: drug,
        amount: drug.split(' - ')[1],
        timestamp: timestamp
    };

    status.textContent = 'Processing...';

    const response = await fetch('/transaction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(transaction)
    });

    const result = await response.json();
    status.textContent = result.message;
}

async function downloadReceipt(type) {
    window.location.href = type === 'single' ? '/receipt' : '/all-receipts';
}